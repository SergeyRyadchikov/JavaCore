package gb.javacore.lesson4;
/* 
@author Sergey Ryadchikov
 */


public class App {
    public static void main(String[] args) {
        Controller.buttonClick();
    }
}
