package gb.javacore.lesson4.Exceptions;
/* 
@author Sergey Ryadchikov
 */

public class CustomerException extends Exception {
    public CustomerException(String message) {
        super(message);
    }
}
