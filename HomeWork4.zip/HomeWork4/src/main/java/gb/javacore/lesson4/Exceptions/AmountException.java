package gb.javacore.lesson4.Exceptions;
/* 
@author Sergey Ryadchikov
 */

public class AmountException extends Exception {
    public AmountException(String message) {
        super(message);
    }
}
