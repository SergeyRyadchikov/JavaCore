package gb.javacore.lesson4.Exceptions;
/* 
@author Sergey Ryadchikov
 */

public class ProductException extends Exception {
    public ProductException(String message) {
        super(message);
    }
}
